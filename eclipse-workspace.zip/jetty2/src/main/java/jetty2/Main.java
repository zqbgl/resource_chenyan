package jetty2;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

import java.util.Scanner;

import org.openqa.selenium.By;

public class Main {

    public static void main(String[] args){
        Jetty jetty = new Jetty();
        
		try {
			jetty.start();
			System.setProperty("webdriver.chrome.driver",
					"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
			Scanner scanner = new Scanner(System.in);
			int a = scanner.nextInt();
			System.out.println(a);
			scanner.close();
			open("http://localhost:8887/");
			$(By.name("name")).setValue("������");
			$("#submit").click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				jetty.stop();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    }
}
