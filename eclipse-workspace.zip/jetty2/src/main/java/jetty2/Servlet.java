package jetty2;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
    	response.getWriter().println("doGet");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
//    	System.out.println(request.getParameter("name"));
    	request.setCharacterEncoding("Windows-31J");
    	System.out.println(request.getParameter("name"));
    	response.setCharacterEncoding("Windows-31J");
    	response.getWriter().println(request.getParameter("name"));
    }
}
