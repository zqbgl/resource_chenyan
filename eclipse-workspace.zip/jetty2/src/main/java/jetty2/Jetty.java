package jetty2;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;

public class Jetty {
	
    Server server = new Server(8887);
    
    public void start() throws Exception {
        WebAppContext context = new WebAppContext();
        context.setDescriptor("./src/main/webapp/WEB-INF/web.xml");
        context.setResourceBase("./src/main/webapp");
        context.setContextPath("/");
        context.setParentLoaderPriority(true);
        server.setHandler(context);
//        server.setStopAtShutdown(true);
        server.start();
//        server.join();
        System.out.println("Jetty start");
    }
    
    public void stop() throws Exception {
        server.stop();
        System.out.println("Jetty stop");
    }
}
