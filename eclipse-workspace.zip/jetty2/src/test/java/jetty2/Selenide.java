package jetty2;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



import static com.codeborne.selenide.Selenide.*;

import java.util.Scanner;

import com.codeborne.selenide.Configuration.*;

public class Selenide {
	
	Jetty jetty = new Jetty();
	
    @Before
    public void runBeforeTestMethod() throws Exception {
    	jetty.start();
        System.out.println("@Before - runBeforeTestMethod");
//    	System.setProperty("selenide.browser", "chrome");
//    	System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
//    	Configuration.browser = "chrome";
//        Configuration.browserSize = "1600x900";
//        Configuration.holdBrowserOpen = true;
    }

    @After
    public void runAfterTestMethod() throws Exception {
    	jetty.stop();
        System.out.println("@After - runAfterTestMethod");
    }
 
    @Test
    public void test_method_1() {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        System.out.println(a);
        scanner.close();
    	open("http://localhost:8889/");
    	$(By.name("name")).setValue("������");
    	$("#submit").click();
        System.out.println("@Test - test_method_1");
    }
}
